"use client";

import Link from "next/link";
import { useCart } from "@/components/cart/CartProvider";
import FoodImage from "@/components/menu/FoodImage";
import QuantityControl from "@/components/menu/QuantityControl";
import { TrashIcon } from "@/components/ui/Icons";
import { formatPKR } from "@/lib/format";

export default function CartPage() {
  const { items, hydrated, subtotal, deliveryFee, total, setQuantity, removeItem } = useCart();

  if (!hydrated) {
    return (
      <div className="container-x py-10" aria-busy="true">
        <div className="h-10 w-40 animate-pulse rounded-xl bg-ink-900/10" />
        <div className="mt-6 h-40 animate-pulse rounded-3xl bg-ink-900/10" />
      </div>
    );
  }

  if (items.length === 0) {
    return (
      <div className="container-x py-20 text-center">
        <p className="text-6xl">🛒</p>
        <h1 className="mt-4 text-3xl font-extrabold">Your cart is empty</h1>
        <p className="mt-2 text-ink-900/70">Add a burger, some fries or a wrap to get started.</p>
        <Link href="/menu" className="btn-primary mt-6 px-8 py-4 text-base">Browse the menu</Link>
      </div>
    );
  }

  return (
    <div className="container-x py-10">
      <h1 className="text-4xl font-extrabold">Your cart</h1>

      <div className="mt-8 grid gap-8 lg:grid-cols-[1fr_380px]">
        <ul className="space-y-4">
          {items.map((item) => (
            <li key={item.id} className="flex gap-4 rounded-3xl border-2 border-ink-900/10 p-3 sm:p-4">
              <FoodImage
                src={item.image_url}
                alt={item.name}
                category={item.category}
                className="h-24 w-24 shrink-0 rounded-2xl sm:h-28 sm:w-28"
              />
              <div className="flex min-w-0 flex-1 flex-col">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <p className="truncate text-lg font-extrabold">{item.name}</p>
                    <p className="text-sm text-ink-900/60">{formatPKR(item.price)} each</p>
                  </div>
                  <button
                    type="button"
                    onClick={() => removeItem(item.id)}
                    aria-label={`Remove ${item.name}`}
                    className="grid h-9 w-9 shrink-0 place-items-center rounded-full text-brand-700 hover:bg-brand-50"
                  >
                    <TrashIcon />
                  </button>
                </div>
                <div className="mt-auto flex items-center justify-between pt-3">
                  <QuantityControl quantity={item.quantity} name={item.name} size="sm" onChange={(n) => setQuantity(item.id, n)} />
                  <p className="text-lg font-extrabold">{formatPKR(item.price * item.quantity)}</p>
                </div>
              </div>
            </li>
          ))}
        </ul>

        <aside className="h-fit rounded-3xl border-2 border-ink-900 p-6 lg:sticky lg:top-24">
          <h2 className="text-xl font-extrabold">Order summary</h2>
          <dl className="mt-4 space-y-2 text-sm">
            <div className="flex justify-between"><dt>Subtotal</dt><dd className="font-bold">{formatPKR(subtotal)}</dd></div>
            <div className="flex justify-between"><dt>Delivery fee</dt><dd className="font-bold">{formatPKR(deliveryFee)}</dd></div>
            <div className="flex justify-between border-t-2 border-ink-900/10 pt-3 text-lg">
              <dt className="font-extrabold">Total</dt><dd className="font-extrabold">{formatPKR(total)}</dd>
            </div>
          </dl>
          <p className="mt-3 text-xs text-ink-900/60">Pay cash to the rider when your order arrives.</p>
          <Link href="/checkout" className="btn-primary mt-5 w-full py-4 text-base">Go to checkout</Link>
          <Link href="/menu" className="mt-3 block text-center text-sm font-bold underline">Add more items</Link>
        </aside>
      </div>
    </div>
  );
}
