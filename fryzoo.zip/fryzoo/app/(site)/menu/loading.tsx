export default function MenuLoading() {
  return (
    <div className="container-x py-10" aria-busy="true" aria-label="Loading menu">
      <div className="h-10 w-48 animate-pulse rounded-xl bg-ink-900/10" />
      <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {Array.from({ length: 6 }).map((_, i) => (
          <div key={i} className="overflow-hidden rounded-3xl border-2 border-ink-900/10">
            <div className="aspect-[4/3] animate-pulse bg-ink-900/10" />
            <div className="space-y-3 p-4">
              <div className="h-5 w-2/3 animate-pulse rounded bg-ink-900/10" />
              <div className="h-4 w-full animate-pulse rounded bg-ink-900/10" />
              <div className="h-9 w-24 animate-pulse rounded-full bg-ink-900/10" />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
