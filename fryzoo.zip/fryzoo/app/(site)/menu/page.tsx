import type { Metadata } from "next";
import { createClient } from "@/lib/supabase/server";
import { CATEGORIES } from "@/lib/config";
import type { MenuItem } from "@/lib/types";
import MenuBrowser from "@/components/menu/MenuBrowser";

export const metadata: Metadata = {
  title: "Menu",
  description: "Burgers, loaded fries, wraps, fried chicken and drinks from Fryzoo, Lahore.",
};

export default async function MenuPage({
  searchParams,
}: {
  searchParams: Promise<{ category?: string }>;
}) {
  const { category } = await searchParams;
  const supabase = await createClient();
  const { data, error } = await supabase.from("menu_items").select("*").order("created_at", { ascending: true });

  const order = (c: string) => (CATEGORIES as readonly string[]).indexOf(c);
  const items = ((data ?? []) as MenuItem[]).sort((a, b) => order(a.category) - order(b.category));

  return (
    <div className="container-x py-10">
      <h1 className="text-4xl font-extrabold sm:text-5xl">Our menu</h1>
      <p className="mt-2 text-ink-900/70">All prices in PKR. Pay cash on delivery.</p>

      {error ? (
        <div className="mt-8 rounded-3xl border-2 border-brand-600 bg-brand-50 p-8 text-center">
          <p className="text-xl font-extrabold">We could not load the menu</p>
          <p className="mt-1 text-sm text-ink-900/70">Please refresh the page. If the problem continues, call us.</p>
        </div>
      ) : (
        <div className="mt-6">
          <MenuBrowser items={items} initialCategory={category ?? "All"} />
        </div>
      )}
    </div>
  );
}
