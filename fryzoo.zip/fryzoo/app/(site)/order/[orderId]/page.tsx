import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import type { PublicOrder } from "@/lib/types";
import OrderTracker from "@/components/order/OrderTracker";

export const metadata: Metadata = { title: "Your order", robots: { index: false, follow: false } };

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

export default async function OrderPage({ params }: { params: Promise<{ orderId: string }> }) {
  const { orderId } = await params;
  if (!UUID.test(orderId)) notFound();

  const supabase = await createClient();
  const { data, error } = await supabase.rpc("get_order_public", { p_order_id: orderId });

  if (error) {
    return (
      <div className="container-x py-20 text-center">
        <h1 className="text-3xl font-extrabold">We could not load your order</h1>
        <p className="mt-2 text-ink-900/70">Please refresh the page in a moment.</p>
      </div>
    );
  }
  if (!data) notFound();

  return <OrderTracker initialOrder={data as PublicOrder} />;
}
