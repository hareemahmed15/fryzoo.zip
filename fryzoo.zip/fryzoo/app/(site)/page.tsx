import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import { BRAND, CATEGORIES, HERO_IMAGE } from "@/lib/config";
import type { MenuItem } from "@/lib/types";
import ProductCard from "@/components/menu/ProductCard";
import FoodImage from "@/components/menu/FoodImage";
import { ArrowRightIcon, ClockIcon, PhoneIcon, PinIcon } from "@/components/ui/Icons";

const CATEGORY_META: Record<string, { emoji: string; blurb: string }> = {
  Burgers: { emoji: "🍔", blurb: "Smash, zinger and tower" },
  "Loaded Fries": { emoji: "🍟", blurb: "Piled high, sauced well" },
  Wraps: { emoji: "🌯", blurb: "Paratha rolls and tortilla wraps" },
  Chicken: { emoji: "🍗", blurb: "Crispy pieces, wings, strips" },
  Drinks: { emoji: "🥤", blurb: "Cold, fizzy and creamy" },
};

export default async function HomePage() {
  const supabase = await createClient();

  const [featuredRes, popularRes] = await Promise.all([
    supabase
      .from("menu_items")
      .select("*")
      .eq("is_featured", true)
      .eq("available", true)
      .order("created_at", { ascending: true })
      .limit(4),
    supabase.rpc("get_popular_items", { p_limit: 6 }),
  ]);

  const featured = (featuredRes.data ?? []) as MenuItem[];
  const popular = (popularRes.data ?? []) as MenuItem[];
  const loadFailed = Boolean(featuredRes.error || popularRes.error);

  return (
    <>
      {/* HERO */}
      <section className="relative overflow-hidden bg-brand-600 text-white">
        <div className="container-x grid items-center gap-10 py-12 md:grid-cols-2 md:py-20">
          <div>
            <p className="inline-block rounded-full bg-white/15 px-4 py-1.5 text-sm font-bold">
              Delivering across {BRAND.city}
            </p>
            <h1 className="mt-5 text-5xl font-extrabold leading-[1.02] sm:text-6xl lg:text-7xl">
              Burgers, fries and fried chicken, at your door hot.
            </h1>
            <p className="mt-5 max-w-lg text-lg text-white/90">
              Smash burgers, loaded fries, zinger wraps and crispy chicken, cooked when you order. Pay cash when it arrives.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link href="/menu" className="btn-yellow px-7 py-4 text-base">
                Order now <ArrowRightIcon />
              </Link>
              <Link href="#categories" className="btn bg-white/15 px-7 py-4 text-base text-white hover:bg-white/25">
                See what we make
              </Link>
            </div>
          </div>

          <div className="relative mx-auto w-full max-w-md">
            <div className="rounded-full bg-sun-400 p-3 shadow-2xl">
              <FoodImage
                src={HERO_IMAGE}
                alt="Fryzoo burger"
                category="Burgers"
                className="aspect-square w-full rounded-full"
              />
            </div>
            <div className="absolute -bottom-3 -left-2 rotate-[-8deg] rounded-2xl bg-white px-4 py-3 text-ink-900 shadow-xl sm:-left-6">
              <p className="text-xs font-bold text-ink-900/60">Burgers from</p>
              <p className="font-display text-2xl font-extrabold">Rs. 550</p>
            </div>
            <div className="absolute -right-1 top-6 rotate-[6deg] rounded-2xl bg-ink-900 px-4 py-3 text-white shadow-xl sm:-right-4">
              <p className="text-xs font-bold text-white/60">Payment</p>
              <p className="font-display text-lg font-extrabold">Cash on delivery</p>
            </div>
          </div>
        </div>
      </section>

      {loadFailed && (
        <div className="container-x mt-6">
          <p className="rounded-2xl bg-sun-100 p-4 text-sm font-medium">
            We could not load the menu right now. Please refresh the page in a moment.
          </p>
        </div>
      )}

      {/* CATEGORIES */}
      <section id="categories" className="container-x py-14">
        <h2 className="text-3xl font-extrabold sm:text-4xl">Pick your craving</h2>
        <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
          {CATEGORIES.map((c) => (
            <Link
              key={c}
              href={`/menu?category=${encodeURIComponent(c)}`}
              className="group rounded-3xl border-2 border-ink-900/10 bg-sun-50 p-5 transition hover:border-ink-900 hover:bg-sun-100"
            >
              <span className="text-4xl">{CATEGORY_META[c].emoji}</span>
              <p className="mt-3 text-lg font-extrabold">{c}</p>
              <p className="text-sm text-ink-900/70">{CATEGORY_META[c].blurb}</p>
            </Link>
          ))}
        </div>
      </section>

      {/* FEATURED */}
      {featured.length > 0 && (
        <section className="bg-sun-50 py-14">
          <div className="container-x">
            <div className="flex items-end justify-between gap-4">
              <h2 className="text-3xl font-extrabold sm:text-4xl">Featured this week</h2>
              <Link href="/menu" className="hidden text-sm font-bold text-brand-700 underline sm:block">Full menu</Link>
            </div>
            <div className="mt-6 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
              {featured.map((item) => <ProductCard key={item.id} item={item} />)}
            </div>
          </div>
        </section>
      )}

      {/* POPULAR */}
      {popular.length > 0 && (
        <section id="popular" className="container-x scroll-mt-20 py-14">
          <h2 className="text-3xl font-extrabold sm:text-4xl">Most ordered</h2>
          <p className="mt-2 text-ink-900/70">What Lahore keeps coming back for.</p>
          <div className="mt-6 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {popular.map((item) => <ProductCard key={item.id} item={item} />)}
          </div>
        </section>
      )}

      {/* ORDER CTA */}
      <section className="bg-ink-900 py-14 text-white">
        <div className="container-x flex flex-col items-start justify-between gap-6 md:flex-row md:items-center">
          <div>
            <h2 className="text-3xl font-extrabold sm:text-4xl">Hungry? It takes two minutes.</h2>
            <p className="mt-2 text-white/70">Choose your food, enter your address, pay when it arrives.</p>
          </div>
          <Link href="/menu" className="btn-yellow px-8 py-4 text-base">Start your order <ArrowRightIcon /></Link>
        </div>
      </section>

      {/* ABOUT */}
      <section id="about" className="container-x scroll-mt-20 py-14">
        <div className="grid gap-8 md:grid-cols-2 md:items-center">
          <div>
            <h2 className="text-3xl font-extrabold sm:text-4xl">Street-food spirit, proper kitchen standards</h2>
            <p className="mt-4 max-w-prose text-ink-900/80">
              Fryzoo started with one idea: the burger you crave at midnight should still be hot and crunchy when it
              reaches you. We marinate our chicken in-house, smash our beef patties to order and fry everything in
              fresh oil, then pack it so it travels well across {BRAND.city}.
            </p>
          </div>
          <ul className="grid gap-3 sm:grid-cols-3 md:grid-cols-1">
            {[
              ["Cooked when you order", "Nothing sits under a heat lamp."],
              ["Pay cash on delivery", "No cards or online payments needed."],
              ["Open late", BRAND.hours],
            ].map(([title, text]) => (
              <li key={title} className="rounded-2xl border-2 border-ink-900/10 p-4">
                <p className="font-extrabold">{title}</p>
                <p className="text-sm text-ink-900/70">{text}</p>
              </li>
            ))}
          </ul>
        </div>
      </section>

      {/* CONTACT */}
      <section id="contact" className="scroll-mt-20 bg-sun-50 py-14">
        <div className="container-x">
          <h2 className="text-3xl font-extrabold sm:text-4xl">Find us</h2>
          <div className="mt-6 grid gap-4 md:grid-cols-3">
            <div className="panel flex gap-3"><PinIcon className="mt-0.5 h-6 w-6 shrink-0 text-brand-600" />
              <div><p className="font-extrabold">Address</p><p className="text-sm text-ink-900/75">{BRAND.address}</p>
                <p className="mt-1 text-sm text-ink-900/75">We deliver to {BRAND.deliveryAreas}.</p></div></div>
            <div className="panel flex gap-3"><PhoneIcon className="mt-0.5 h-6 w-6 shrink-0 text-brand-600" />
              <div><p className="font-extrabold">Call us</p>
                <a href={BRAND.phoneHref} className="text-sm font-bold text-brand-700 underline">{BRAND.phone}</a>
                <p className="mt-1 text-sm text-ink-900/75">{BRAND.email}</p></div></div>
            <div className="panel flex gap-3"><ClockIcon className="mt-0.5 h-6 w-6 shrink-0 text-brand-600" />
              <div><p className="font-extrabold">Opening hours</p><p className="text-sm text-ink-900/75">{BRAND.hours}</p></div></div>
          </div>
        </div>
      </section>
    </>
  );
}
