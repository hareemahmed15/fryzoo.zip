import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import AdminNav from "@/components/admin/AdminNav";
import SignOutButton from "@/components/admin/SignOutButton";

// Every page inside app/admin/(panel)/ is protected here:
// 1) must be logged in, 2) must be listed in the admin_users table.
export default async function AdminPanelLayout({ children }: { children: React.ReactNode }) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) redirect("/admin/login");

  const { data: isAdmin } = await supabase.rpc("is_admin");

  if (!isAdmin) {
    return (
      <div className="grid min-h-screen place-items-center px-4">
        <div className="panel max-w-md text-center">
          <p className="text-5xl">🔒</p>
          <h1 className="mt-3 text-2xl font-extrabold">This account is not an admin</h1>
          <p className="mt-2 text-sm text-ink-900/70">
            You are signed in as {user.email}, but this account has not been given restaurant admin access.
          </p>
          <div className="mt-5"><SignOutButton className="btn-primary" /></div>
        </div>
      </div>
    );
  }

  return (
    <>
      <AdminNav email={user.email ?? ""} />
      <main className="container-x py-8">{children}</main>
    </>
  );
}
