import MenuManager from "@/components/admin/MenuManager";

export default function AdminMenuPage() {
  return (
    <>
      <h1 className="text-3xl font-extrabold">Menu management</h1>
      <div className="mt-6"><MenuManager /></div>
    </>
  );
}
