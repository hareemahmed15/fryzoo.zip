import OrdersBoard from "@/components/admin/OrdersBoard";

export default function AdminOrdersPage() {
  return (
    <>
      <h1 className="text-3xl font-extrabold">Orders</h1>
      <p className="mt-1 text-sm text-ink-900/70">Newest first. New orders appear automatically.</p>
      <div className="mt-6"><OrdersBoard /></div>
    </>
  );
}
