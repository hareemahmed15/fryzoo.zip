import DashboardStats from "@/components/admin/DashboardStats";

export default function AdminDashboardPage() {
  return (
    <>
      <h1 className="text-3xl font-extrabold">Dashboard</h1>
      <p className="mt-1 text-sm text-ink-900/70">Updates by itself when new orders arrive.</p>
      <div className="mt-6"><DashboardStats /></div>
    </>
  );
}
