// Everything you are likely to edit later (name, phone, address...) lives here.

export const BRAND = {
  name: "Fryzoo",
  tagline: "Crispy. Loaded. Delivered.",
  city: "Lahore",
  phone: "0300 0000000",
  phoneHref: "tel:+923000000000",
  email: "hello@fryzoo.pk",
  address: "Shop 12, Main Boulevard, Gulberg III, Lahore",
  hours: "Every day, 12:00 PM to 2:00 AM",
  deliveryAreas: "Gulberg, DHA, Johar Town, Model Town, Cantt and Garden Town",
} as const;

// Used only until the real fee loads from the database (table: app_settings, key: delivery_fee).
// To CHANGE the fee: Supabase -> Table Editor -> app_settings -> edit the delivery_fee value.
export const DEFAULT_DELIVERY_FEE = 150;

export const MAX_QTY_PER_ITEM = 20;

export const CATEGORIES = ["Burgers", "Loaded Fries", "Wraps", "Chicken", "Drinks"] as const;

export const ORDER_STATUSES = [
  "pending",
  "accepted",
  "preparing",
  "ready",
  "completed",
  "rejected",
  "cancelled",
] as const;

export const HERO_IMAGE =
  "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=1000&q=80";
