-- =====================================================================
-- FRYZOO: tables, constraints, indexes, security (RLS), functions, realtime
-- Run ONCE in: Supabase Dashboard -> SQL Editor -> New query -> paste -> Run.
-- It is safe to run again if something failed half-way.
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1. TABLES
-- ---------------------------------------------------------------------

create table if not exists public.menu_items (
  id          uuid primary key default gen_random_uuid(),
  name        text not null check (char_length(trim(name)) between 2 and 80),
  description text not null default '' check (char_length(description) <= 300),
  price       numeric(10,2) not null check (price >= 0),
  category    text not null check (category in ('Burgers','Loaded Fries','Wraps','Chicken','Drinks')),
  image_url   text,
  available   boolean not null default true,
  is_featured boolean not null default false,   -- shows in "Featured" on the home page
  created_at  timestamptz not null default now()
);

create table if not exists public.orders (
  id               uuid primary key default gen_random_uuid(),
  order_number     text not null unique,
  customer_name    text not null check (char_length(trim(customer_name)) between 2 and 80),
  customer_phone   text not null check (char_length(customer_phone) between 10 and 15),
  delivery_address text not null check (char_length(trim(delivery_address)) between 10 and 300),
  notes            text check (notes is null or char_length(notes) <= 300),
  subtotal         numeric(10,2) not null check (subtotal >= 0),
  delivery_fee     numeric(10,2) not null check (delivery_fee >= 0),
  total            numeric(10,2) not null check (total >= 0),
  payment_method   text not null default 'cod' check (payment_method in ('cod')),
  status           text not null default 'pending'
                   check (status in ('pending','accepted','preparing','ready','completed','rejected','cancelled')),
  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now()
);

create table if not exists public.order_items (
  id           uuid primary key default gen_random_uuid(),
  order_id     uuid not null references public.orders(id) on delete cascade,
  -- If a menu item is deleted later, old orders keep working (item_name is a snapshot).
  menu_item_id uuid references public.menu_items(id) on delete set null,
  item_name    text not null,
  quantity     integer not null check (quantity between 1 and 50),
  unit_price   numeric(10,2) not null check (unit_price >= 0),
  created_at   timestamptz not null default now()
);

-- Single place to change business settings (e.g. delivery fee)
create table if not exists public.app_settings (
  key   text primary key,
  value numeric not null
);
insert into public.app_settings (key, value) values ('delivery_fee', 150)
on conflict (key) do nothing;

-- Who is a restaurant admin. Being logged in is NOT enough; you must be in this table.
create table if not exists public.admin_users (
  user_id    uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

-- ---------------------------------------------------------------------
-- 2. INDEXES
-- ---------------------------------------------------------------------
create index if not exists menu_items_category_idx   on public.menu_items (category);
create index if not exists menu_items_available_idx  on public.menu_items (available);
create index if not exists menu_items_featured_idx   on public.menu_items (is_featured) where is_featured;
create index if not exists orders_created_at_idx     on public.orders (created_at desc);
create index if not exists orders_status_idx         on public.orders (status);
create index if not exists order_items_order_id_idx  on public.order_items (order_id);
create index if not exists order_items_menu_item_idx on public.order_items (menu_item_id);

-- Human-readable order numbers: FZ-250124-1001
create sequence if not exists public.order_number_seq start 1001;

-- ---------------------------------------------------------------------
-- 3. HELPER FUNCTIONS + TRIGGERS
-- ---------------------------------------------------------------------

-- Is the currently logged-in user a restaurant admin?
create or replace function public.is_admin()
returns boolean
language sql stable security definer set search_path = public
as $$
  select exists (select 1 from public.admin_users where user_id = auth.uid());
$$;

-- Keep orders.updated_at fresh
create or replace function public.set_updated_at()
returns trigger language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists orders_set_updated_at on public.orders;
create trigger orders_set_updated_at
before update on public.orders
for each row execute function public.set_updated_at();

-- When an order's status changes, broadcast it on a channel named after the
-- order's (unguessable) UUID so the customer's page updates instantly.
-- Wrapped in an exception block so a Realtime problem can never block an admin's status change.
create or replace function public.broadcast_order_status()
returns trigger
language plpgsql security definer set search_path = public
as $$
begin
  begin
    perform realtime.send(
      jsonb_build_object('status', new.status, 'updated_at', new.updated_at),
      'status',
      'order:' || new.id::text,
      false
    );
  exception when others then
    null;
  end;
  return new;
end;
$$;

drop trigger if exists orders_broadcast_status on public.orders;
create trigger orders_broadcast_status
after update on public.orders
for each row
when (old.status is distinct from new.status)
execute function public.broadcast_order_status();

-- ---------------------------------------------------------------------
-- 4. CUSTOMER FUNCTIONS (the only way customers touch orders)
-- ---------------------------------------------------------------------

-- Creates an order. Prices and the delivery fee are read from the DATABASE,
-- never trusted from the browser, so a customer cannot change what they pay.
create or replace function public.place_order(
  p_customer_name    text,
  p_customer_phone   text,
  p_delivery_address text,
  p_notes            text,
  p_items            jsonb
)
returns jsonb
language plpgsql security definer set search_path = public
as $$
declare
  v_name     text := trim(coalesce(p_customer_name, ''));
  v_phone    text := regexp_replace(coalesce(p_customer_phone, ''), '[^0-9+]', '', 'g');
  v_address  text := trim(coalesce(p_delivery_address, ''));
  v_notes    text := nullif(trim(coalesce(p_notes, '')), '');
  v_fee      numeric(10,2);
  v_subtotal numeric(10,2) := 0;
  v_order_id uuid;
  v_number   text;
  v_line     jsonb;
  v_item     public.menu_items%rowtype;
  v_qty      integer;
begin
  if char_length(v_name) < 2 or char_length(v_name) > 80 then
    raise exception 'Please enter your name.';
  end if;
  if v_phone !~ '^(\+92|0092|92|0)?3[0-9]{9}$' then
    raise exception 'Please enter a valid Pakistani mobile number, e.g. 0300 1234567.';
  end if;
  v_phone := '0' || right(v_phone, 10);   -- store as 03XXXXXXXXX
  if char_length(v_address) < 10 or char_length(v_address) > 300 then
    raise exception 'Please enter your full delivery address.';
  end if;
  if v_notes is not null and char_length(v_notes) > 300 then
    raise exception 'Notes are too long (300 characters max).';
  end if;
  if p_items is null or jsonb_typeof(p_items) <> 'array'
     or jsonb_array_length(p_items) = 0 or jsonb_array_length(p_items) > 50 then
    raise exception 'Your cart is empty.';
  end if;

  select coalesce((select value from public.app_settings where key = 'delivery_fee'), 150) into v_fee;

  v_number := 'FZ-' || to_char(timezone('Asia/Karachi', now()), 'YYMMDD')
              || '-' || nextval('public.order_number_seq')::text;

  insert into public.orders
    (order_number, customer_name, customer_phone, delivery_address, notes,
     subtotal, delivery_fee, total, payment_method, status)
  values
    (v_number, v_name, v_phone, v_address, v_notes, 0, v_fee, v_fee, 'cod', 'pending')
  returning id into v_order_id;

  for v_line in select value from jsonb_array_elements(p_items) loop
    begin
      v_qty := (v_line->>'quantity')::integer;
    exception when others then
      raise exception 'Invalid quantity in your cart.';
    end;
    if v_qty is null or v_qty < 1 or v_qty > 20 then
      raise exception 'Each item must have a quantity between 1 and 20.';
    end if;

    begin
      select * into v_item from public.menu_items where id = (v_line->>'menu_item_id')::uuid;
    exception when others then
      raise exception 'Your cart contains an invalid item. Please clear it and try again.';
    end;
    if not found then
      raise exception 'An item in your cart is no longer on the menu. Please review your cart.';
    end if;
    if not v_item.available then
      raise exception '% is currently unavailable. Please remove it from your cart.', v_item.name;
    end if;

    insert into public.order_items (order_id, menu_item_id, item_name, quantity, unit_price)
    values (v_order_id, v_item.id, v_item.name, v_qty, v_item.price);

    v_subtotal := v_subtotal + (v_item.price * v_qty);
  end loop;

  update public.orders set subtotal = v_subtotal, total = v_subtotal + v_fee where id = v_order_id;

  return jsonb_build_object('order_id', v_order_id, 'order_number', v_number);
end;
$$;

-- Lets a customer read ONE order if they know its (random, unguessable) UUID.
-- Customers can NOT list or search orders.
create or replace function public.get_order_public(p_order_id uuid)
returns jsonb
language sql stable security definer set search_path = public
as $$
  select jsonb_build_object(
    'id', o.id,
    'order_number', o.order_number,
    'customer_name', o.customer_name,
    'customer_phone', o.customer_phone,
    'delivery_address', o.delivery_address,
    'notes', o.notes,
    'subtotal', o.subtotal,
    'delivery_fee', o.delivery_fee,
    'total', o.total,
    'payment_method', o.payment_method,
    'status', o.status,
    'created_at', o.created_at,
    'updated_at', o.updated_at,
    'items', coalesce((
      select jsonb_agg(
               jsonb_build_object('name', oi.item_name, 'quantity', oi.quantity, 'unit_price', oi.unit_price)
               order by oi.created_at)
      from public.order_items oi where oi.order_id = o.id
    ), '[]'::jsonb)
  )
  from public.orders o
  where o.id = p_order_id;
$$;

-- Most-ordered available items (used by "Popular" on the home page).
-- Returns only menu rows, never any order data.
create or replace function public.get_popular_items(p_limit integer default 6)
returns setof public.menu_items
language sql stable security definer set search_path = public
as $$
  select m.*
  from public.menu_items m
  left join public.order_items oi on oi.menu_item_id = m.id
  where m.available
  group by m.id
  order by coalesce(sum(oi.quantity), 0) desc, m.created_at asc
  limit greatest(p_limit, 1);
$$;

-- Only run the functions you intend to expose
revoke all on function public.place_order(text, text, text, text, jsonb) from public;
revoke all on function public.get_order_public(uuid) from public;
revoke all on function public.get_popular_items(integer) from public;
revoke all on function public.is_admin() from public;
grant execute on function public.place_order(text, text, text, text, jsonb) to anon, authenticated;
grant execute on function public.get_order_public(uuid) to anon, authenticated;
grant execute on function public.get_popular_items(integer) to anon, authenticated;
grant execute on function public.is_admin() to anon, authenticated;

-- ---------------------------------------------------------------------
-- 5. ROW LEVEL SECURITY
-- ---------------------------------------------------------------------
alter table public.menu_items  enable row level security;
alter table public.orders      enable row level security;
alter table public.order_items enable row level security;
alter table public.app_settings enable row level security;
alter table public.admin_users enable row level security;

-- menu_items: everyone can read the menu; only admins can change it
drop policy if exists "Anyone can view menu"   on public.menu_items;
drop policy if exists "Admins insert menu"     on public.menu_items;
drop policy if exists "Admins update menu"     on public.menu_items;
drop policy if exists "Admins delete menu"     on public.menu_items;
create policy "Anyone can view menu" on public.menu_items for select to anon, authenticated using (true);
create policy "Admins insert menu"   on public.menu_items for insert to authenticated with check (public.is_admin());
create policy "Admins update menu"   on public.menu_items for update to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "Admins delete menu"   on public.menu_items for delete to authenticated using (public.is_admin());

-- orders: NO customer policies at all (customers use place_order / get_order_public).
drop policy if exists "Admins view orders"   on public.orders;
drop policy if exists "Admins update orders" on public.orders;
create policy "Admins view orders"   on public.orders for select to authenticated using (public.is_admin());
create policy "Admins update orders" on public.orders for update to authenticated using (public.is_admin()) with check (public.is_admin());

-- order_items: admins can read; nobody can write directly (only place_order writes)
drop policy if exists "Admins view order items" on public.order_items;
create policy "Admins view order items" on public.order_items for select to authenticated using (public.is_admin());

-- app_settings: public read (the cart shows the delivery fee); only admins can edit
drop policy if exists "Anyone can read settings" on public.app_settings;
drop policy if exists "Admins update settings"   on public.app_settings;
create policy "Anyone can read settings" on public.app_settings for select to anon, authenticated using (true);
create policy "Admins update settings"   on public.app_settings for update to authenticated using (public.is_admin()) with check (public.is_admin());

-- admin_users: a logged-in user may only see their own row
drop policy if exists "Users read own admin row" on public.admin_users;
create policy "Users read own admin row" on public.admin_users for select to authenticated using (user_id = auth.uid());

-- ---------------------------------------------------------------------
-- 6. TABLE PRIVILEGES (second lock behind RLS)
-- ---------------------------------------------------------------------
revoke all on public.orders, public.order_items, public.admin_users from anon;
revoke insert, update, delete, truncate on public.menu_items, public.app_settings from anon;

revoke insert, delete, truncate, references, trigger on public.orders from authenticated;
revoke update on public.orders from authenticated;
grant  update (status) on public.orders to authenticated;       -- admins can ONLY change the status column

revoke insert, update, delete, truncate on public.order_items from authenticated;
revoke insert, update, delete, truncate on public.admin_users from authenticated;
revoke insert, delete, truncate on public.app_settings from authenticated;

-- ---------------------------------------------------------------------
-- 7. REALTIME (admin dashboard receives new orders without refreshing)
-- ---------------------------------------------------------------------
do $$
begin
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'orders'
  ) then
    alter publication supabase_realtime add table public.orders;
  end if;
end $$;
