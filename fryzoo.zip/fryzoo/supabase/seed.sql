-- =====================================================================
-- FRYZOO demo menu (prices in PKR). Run ONCE, after the migration.
-- Photos are Unsplash links; replace any of them from Admin -> Menu.
-- =====================================================================
insert into public.menu_items (name, description, price, category, image_url, available, is_featured) values
-- BURGERS (5)
('Zinger Burger',        'Crispy spicy chicken fillet, lettuce, mayo and our house hot sauce in a toasted sesame bun.', 650,  'Burgers', 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=800&q=80', true, true),
('Crunchy Chicken Burger','Golden fried chicken patty, coleslaw and garlic mayo. The everyday favourite.',               550,  'Burgers', 'https://images.unsplash.com/photo-1550547660-d9450f859349?auto=format&fit=crop&w=800&q=80', true, false),
('Double Smash Beef Burger','Two smashed beef patties, melted cheddar, caramelised onions and Fryzoo sauce.',            1190, 'Burgers', 'https://images.unsplash.com/photo-1571091718767-18b5b1457add?auto=format&fit=crop&w=800&q=80', true, true),
('Tower Burger',         'Crispy fillet, hash brown, cheese slice and jalapeno stacked high. Come hungry.',                 890,  'Burgers', 'https://images.unsplash.com/photo-1586190848861-99aa4a171e90?auto=format&fit=crop&w=800&q=80', true, false),
('Mushroom Swiss Burger','Juicy beef patty topped with sauteed mushrooms and creamy Swiss-style cheese.',                  990,  'Burgers', 'https://images.unsplash.com/photo-1594212699903-ec8a3eca50f5?auto=format&fit=crop&w=800&q=80', true, false),
-- LOADED FRIES (4)
('Pizza Fries',          'Crispy fries loaded with chicken tikka, mozzarella, olives and pizza sauce.',                     690,  'Loaded Fries', 'https://images.unsplash.com/photo-1573080496219-bb080dd4f877?auto=format&fit=crop&w=800&q=80', true, true),
('Peri Peri Loaded Fries','Fries tossed in peri peri masala with chicken chunks and cheese sauce.',                        590,  'Loaded Fries', 'https://images.unsplash.com/photo-1630384060421-cb20d0e0649d?auto=format&fit=crop&w=800&q=80', true, false),
('Cheesy Crunch Fries',  'Golden fries under a blanket of cheese sauce with crunchy chicken bits and jalapenos.',           650,  'Loaded Fries', 'https://images.unsplash.com/photo-1585109649139-366815a0d713?auto=format&fit=crop&w=800&q=80', true, false),
('Zinger Loaded Fries',  'Fries topped with sliced zinger strips, garlic mayo and hot sauce.',                              790,  'Loaded Fries', 'https://images.unsplash.com/photo-1576107232684-1279f390859f?auto=format&fit=crop&w=800&q=80', true, false),
-- WRAPS (3)
('Zinger Paratha Roll',  'Crispy zinger strips, fresh salad and chutney rolled in a flaky paratha.',                        450,  'Wraps', 'https://images.unsplash.com/photo-1626700051175-6818013e1d4f?auto=format&fit=crop&w=800&q=80', true, true),
('Malai Boti Wrap',      'Creamy malai boti chicken, onions and mint sauce in a soft tortilla.',                            520,  'Wraps', 'https://images.unsplash.com/photo-1565299585323-38d6b0865b47?auto=format&fit=crop&w=800&q=80', true, false),
('Crispy Mexican Wrap',  'Crispy chicken, beans, corn, cheese and chipotle sauce in a toasted wrap.',                       590,  'Wraps', 'https://images.unsplash.com/photo-1599974579688-8dbdd335c77f?auto=format&fit=crop&w=800&q=80', true, false),
-- CHICKEN (4)
('Crispy Fried Chicken (2 pcs)','Our signature 11-spice crispy fried chicken, served hot.',                                  690,  'Chicken', 'https://images.unsplash.com/photo-1626645738196-c2a7c87a8f58?auto=format&fit=crop&w=800&q=80', true, true),
('Hot Wings (6 pcs)',    'Spicy, sticky wings with a smoky chili glaze.',                                                   650,  'Chicken', 'https://images.unsplash.com/photo-1569058242253-92a9c755a0ec?auto=format&fit=crop&w=800&q=80', true, false),
('Chicken Nuggets (9 pcs)','Tender, crunchy nuggets with your choice of garlic mayo or ketchup.',                           590,  'Chicken', 'https://images.unsplash.com/photo-1562967914-608f82629710?auto=format&fit=crop&w=800&q=80', true, false),
('Crispy Strips (5 pcs)','Hand-breaded chicken strips, juicy inside and extra crunchy outside.',                            750,  'Chicken', 'https://images.unsplash.com/photo-1608039829572-78524f79c4c7?auto=format&fit=crop&w=800&q=80', true, false),
-- DRINKS (5)
('Pepsi (345 ml)',       'Ice-cold Pepsi can.',                                                                             130,  'Drinks', 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?auto=format&fit=crop&w=800&q=80', true, false),
('7UP (345 ml)',         'Ice-cold 7UP can.',                                                                               130,  'Drinks', 'https://images.unsplash.com/photo-1581006852262-e4307cf6283a?auto=format&fit=crop&w=800&q=80', true, false),
('Mint Margarita',       'Fresh mint, lemon and soda blended over ice. Lahore summer essential.',                           290,  'Drinks', 'https://images.unsplash.com/photo-1544145945-f90425340c7e?auto=format&fit=crop&w=800&q=80', true, false),
('Oreo Shake',           'Thick, creamy milkshake blended with Oreo cookies.',                                              490,  'Drinks', 'https://images.unsplash.com/photo-1572490122747-3968b75cc699?auto=format&fit=crop&w=800&q=80', true, false),
('Mineral Water (500 ml)','Chilled bottled drinking water.',                                                                 80,   'Drinks', 'https://images.unsplash.com/photo-1523362628745-0c100150b504?auto=format&fit=crop&w=800&q=80', true, false);
